extends CharacterBody2D

static var max_cargo_holds = 500

var username = ""
var status_points = 10

var shield_strength = 20
var max_shield_strength = 20 ## We can get our damage taken as max_shield_strength - shield_strength

var fuel_capacity = 150.0 ## Lets see how much fuel we have
var max_fuel = 150.0

##### And now for player movement... #####
var grid : AStarGrid2D # Yea we gotta define it here too
var target_cell : Vector2i ## Variables in godot dont need to be declared with a type
var current_cell : Vector2i ## But Im declareing these are Vector2i's anyway
## Vector2i's are Integer Vectors, no float positions available
var path = [] ## The players path gets stored in an array
var is_moving = false ## Save if the players moving or not
var current_point = 0
const SPEED = 300
################################

### Boolean for the Cargo holds, .size() gets how many there are
var cargo_holds = [false, false, false, false, false, false, false, false, false, false,
 false, false, false, false, false, false, false, false, false, false]
var latinum_balance = 5000
var ore_held = 0
var illegal_held = 0
var food_held = 0

signal encounter

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass
	#set_physics_process(is_moving) ## Make it so the phyics process function only runs when we're moving
	pass


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	#print(current_cell)
	pass


func grid_setup(grid_given:AStarGrid2D): ## Function to setup our grid
	grid = grid_given ## This is pretty much a constructor for our movement stuff
	current_cell = global_position / grid.cell_size
	## Set what our position is based off of the grids cell size
	target_cell = current_cell
	
	### Pretty much just setting it to never move diagonally and to always move off of right angles ###
	grid.default_compute_heuristic = AStarGrid2D.HEURISTIC_MANHATTAN
	grid.default_estimate_heuristic = AStarGrid2D.HEURISTIC_MANHATTAN
	grid.diagonal_mode = AStarGrid2D.DIAGONAL_MODE_NEVER


func move(target : Vector2i): ## Function to move the player
	## Peramiter is target as a Vector2i (the cell we're gonna want to move to
	
	if (is_moving):
		return ## Cant move if your already moving
	
	if (target != target_cell): ## Only move if your not already there
		path = grid.get_point_path(current_cell, target) ## Save our path to our target
		#print(path)
		
		path = (path as Array).map(func (p): return p + grid.cell_size /2.0)
		## Offset the target to the center of the tile since thats where we want to move
		
		$PathPreview.points = path
		
		target_cell = target ## And save our target_cell value
		
		#print(path)
		## Stop moving if the paths empty
		if (path.is_empty()):
			return
		current_point = 0
		
		GlobalInfo.ended_encounter = false
		is_moving = true
		#print(is_moving)


func _physics_process(delta: float) -> void:
	var encounter_generator = RandomNumberGenerator.new()
	var encounter_roll = encounter_generator.randi_range(0,100)
	
	#print("MOVE")
	if (is_moving):
		if (current_point == path.size() -1): ## Lets see if we're at the end or not!
			velocity = Vector2.ZERO ## Zero our Velocity Vecot
			global_position = path[-1]
			current_cell = global_position / grid.cell_size
			## Set what our position is based off of the grids cell size
			
			$PathPreview.points = []
			is_moving = false
		elif (current_point == (path.size()-1) / 2 and encounter_roll <= 15 and !GlobalInfo.ended_encounter):
			is_moving = false
			GlobalInfo.player_path = path
			GlobalInfo.ship_load_info = save_ship()
			
			emit_signal("encounter")
			
			$"../Camera_Positions/Camera/Wipe_Transition/AnimationPlayer".play("Wipe_Out")
			await $"../Camera_Positions/Camera/Wipe_Transition/AnimationPlayer".animation_finished
			get_tree().change_scene_to_file("res://encounter.tscn")
		else:
			#print("MOVE")
			var direction = (path[current_point + 1] - path[current_point]).normalized()  ## Figure out what direction we're going in
			velocity = direction * SPEED ## Set our velocity to move us in that direction
			#print(direction)
			#print(velocity)
			move_and_slide() ## Move & Slides just one of the ways Godot handles character body movement
			
			## When we get close enough to a point move over to the next one
			if (path[current_point + 1] - global_position).length() < 4:
				fuel_capacity -= 0.25
				current_cell = global_position / grid.cell_size ## Set our current cell to where we are
				current_point += 1 ## And start looking at the next point

### A method to see what our free cargo holds are ###
func get_free_cargo_holds() -> int: ## returns int
	var free_holds = 0
	
	### Loop through how many cargo holds we have
	for i in cargo_holds:
		if !i: ## I would be tree here
			free_holds += 1
	
	return free_holds


##### Save & Load methods #####
func save_ship():
	### save everything to an array, return that array ###
	var save_data = []
	save_data.append(username)
	save_data.append(status_points)
	save_data.append(shield_strength)
	save_data.append(max_shield_strength)
	save_data.append(fuel_capacity)
	save_data.append(max_fuel)
	save_data.append(target_cell)
	save_data.append(current_cell)
	save_data.append(path)
	save_data.append(is_moving)
	save_data.append(current_point)
	save_data.append(cargo_holds)
	save_data.append(latinum_balance)
	save_data.append(ore_held)
	save_data.append(illegal_held)
	save_data.append(food_held)
	save_data.append(position)
	
	return save_data


func load_ship(save_data):
	### And load from that given array ###
	#print(save_data)
	username = save_data[0]
	status_points = save_data[1]
	shield_strength = save_data[2]
	max_shield_strength = save_data[3]
	fuel_capacity = save_data[4]
	max_fuel = save_data[5]
	target_cell = save_data[6]
	current_cell = save_data[7]
	path = save_data[8]
	is_moving = save_data[9]
	current_point = save_data[10]
	cargo_holds = save_data[11]
	latinum_balance = save_data[12]
	ore_held = save_data[13]
	illegal_held = save_data[14]
	food_held = save_data[15]
	position = save_data[16]
