extends Node2D

@export var hit_percent = 90
var round = 1

var is_player_turn = false
#var did_fight = false

var enemy_health = 7
var max_enemy_health = 7

func _ready() -> void:
	var encounter_type_generator = RandomNumberGenerator.new()
	var encounter_type_roll = encounter_type_generator.randi_range(0,1)
	
	if encounter_type_roll:
		GlobalInfo.cop_or_pirate = "cop"
	else:
		GlobalInfo.cop_or_pirate = "pirate"
	
	$Wipe_Transition/AnimationPlayer.play("Wipe_In")
	
	$Ship/Sprite.play("Fly")
	
	$Ship.load_ship(GlobalInfo.ship_load_info)
	
	
	$Enemy.play(GlobalInfo.cop_or_pirate)
	
	await $Wipe_Transition/AnimationPlayer.animation_finished
	
	if GlobalInfo.cop_or_pirate == "cop":
		await display_text("The Police would like to search your ship.
		What would you like to do?")
	else:
		await display_text("The Pirates would like to board your ship.
		What would you like to do?")
	
	is_player_turn = true
	


func _process(delta: float) -> void:
	#### Set the Health Bars ####
	$Player_Menue/Player_Health.max_value = $Ship.max_shield_strength
	$Player_Menue/Player_Health.value = $Ship.shield_strength
	$Enemy_Health/Enemy_Bar.max_value = max_enemy_health
	$Enemy_Health/Enemy_Bar.value = enemy_health
	
	
	if is_player_turn:
		$Player_Menue/Buttons/Fight.disabled = false
		$Player_Menue/Buttons/Flee.disabled = false
		$Player_Menue/Buttons/Surrender.disabled = false
	else:
		$Player_Menue/Buttons/Fight.disabled = true
		$Player_Menue/Buttons/Flee.disabled = true
		$Player_Menue/Buttons/Surrender.disabled = true


func display_text(display_text : String):
	$Player_Menue/Text.text = display_text
	$Player_Menue/Text.visible_characters = 0
	
	while $Player_Menue/Text.visible_characters < (display_text.length()):
		await get_tree().create_timer(0.03).timeout
		$Player_Menue/Text.visible_characters += 1
	
	return


func _on_fight_pressed() -> void:
	var damage_generator = RandomNumberGenerator.new()
	var hit_generator = RandomNumberGenerator.new()
	var hit_roll = hit_generator.randi_range(0,100)
	var damage_done = 0
	var fight_text = ""
	
	is_player_turn = false
	
	if GlobalInfo.cop_or_pirate == "cop":
		fight_text = "5 status points were lost"
		$Ship.status_points -= 5
	else:
		fight_text = "1 status point was gained"
		$Ship.status_points += 1
	
	if round == 1:
		display_text("You choose to fight. %s" % fight_text)
		await get_tree().create_timer(0.5).timeout
	
	### This is if you actually hit ###
	if (hit_roll <= hit_percent):
		damage_done = hit_generator.randi_range(1,3)
		match damage_done:
			1:
				damage_enemy(damage_done)
				await display_text("Your attack was not verry effective")
			2:
				damage_enemy(damage_done)
				await display_text("Your attack made contact with the enemy ship")
			3:
				damage_enemy(damage_done)
				await display_text("Your attack was super effective")
	else:
		await display_text("Your attack missed the enemy ship")
	
	await get_tree().create_timer(0.5).timeout
	enemy_attack()


func damage_enemy(damage_done):
	while damage_done > 0:
			await get_tree().create_timer(0.05).timeout
			enemy_health -= 0.1
			damage_done -= 0.1
			#$Enemy_Health/Enemy_Bar.value = enemy_health
			#print(damage_done)


func enemy_attack():
	var damage_generator = RandomNumberGenerator.new()
	var hit_generator = RandomNumberGenerator.new()
	var hit_roll = hit_generator.randi_range(0,100)
	var damage_done = 0
	var attacker = ""
	
	if GlobalInfo.cop_or_pirate == "cop":
			attacker = "police"
	else:
		attacker = "pirates"
	
	if round != 3:
		
		
		await display_text("The %s are attacking" % attacker)
		await  get_tree().create_timer(0.5).timeout
		
		### This is if you actually hit ###
		if (hit_roll <= hit_percent):
			damage_done = hit_generator.randi_range(1,3)
			match damage_done:
				1:
					damage_player(damage_done)
					await display_text("Their attack was not verry effective")
				2:
					damage_player(damage_done)
					await display_text("Their attack made contact with your ship")
				3:
					damage_player(damage_done)
					await display_text("Their attack was super effective")
		else:
			await display_text("Their attack missed your ship")
		
		await  get_tree().create_timer(0.5).timeout
		await display_text("What would you like to do now?")
		is_player_turn = true
	else:
		await display_text("The %s have gotten lost in a debris field." % attacker)
		await  get_tree().create_timer(0.5).timeout
		end_encounter()
	
	round += 1
	

func damage_player(damage_done):
	while damage_done > 0:
			await get_tree().create_timer(0.05).timeout
			$Ship.shield_strength -= 0.1
			damage_done -= 0.1
			#$Enemy_Health/Enemy_Bar.value = enemy_health
			#print(damage_done)


func end_encounter():
	GlobalInfo.ship_load_info = $Ship.save_ship()
	$Wipe_Transition/AnimationPlayer.play("Wipe_Out")
	GlobalInfo.ended_encounter = true
	await $Wipe_Transition/AnimationPlayer.animation_finished
	get_tree().change_scene_to_file("res://Scenes & Scripts/galaxy.tscn")


func _on_flee_pressed() -> void:
	var flight_text = ""
	
	is_player_turn = false
	
	if GlobalInfo.cop_or_pirate == "cop":
		flight_text = "5 status points were lost"
		$Ship.status_points -= 5
	else:
		flight_text = "1 status point was gained"
		$Ship.status_points += 1

	await display_text("You choose to run. %s" % flight_text)
	await get_tree().create_timer(0.5).timeout

	end_encounter()


func _on_surrender_pressed() -> void:
	if GlobalInfo.cop_or_pirate == "cop":
		await display_text("The police are boarding your ship.")
		await get_tree().create_timer(0.5).timeout
		
		if $Ship.illegal_held > 0:
			await display_text("Illegal items were found. The police have confiscated them and 3 status points were lost")
			
			var total_added = 0
			for i in range($Ship.cargo_holds.size()):
				if $Ship.cargo_holds[i] == true:
					$Ship.cargo_holds[i] = false
					total_added += 1
				
				if (total_added == $Ship.illegal_held):
					break
			
			$Ship.illegal_held = 0
			await get_tree().create_timer(0.5).timeout
		
		else:
			await display_text("No illegal items were found. You are free to go.")
			await get_tree().create_timer(0.5).timeout
			
			end_encounter()
	
	else:
		await display_text("The Pirates are boarding your ship.")
		await get_tree().create_timer(0.5).timeout
		await display_text("They've raided the cargo holds. All cargo has been stolen")
		
		
		
		var total_cart_ammount = $Ship.ore_held + $Ship.food_held + $Ship.illegal_held
		$Ship.ore_held = 0
		$Ship.food_held = 0
		$Ship.illegal_held = 0
		
		
		var total_added = 0
		for i in range($Ship.cargo_holds.size()):
			if $Ship.cargo_holds[i] == true:
				$Ship.cargo_holds[i] = false
				total_added += 1
			
			if (total_added == total_cart_ammount):
				break
		
		await get_tree().create_timer(0.5).timeout
		get_tree().change_scene_to_file("res://Scenes & Scripts/galaxy.tscn")
	
