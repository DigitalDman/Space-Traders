extends Node

## A global script to manage any global information needed between scenes
var ship_load_info = []
var planet_load_info = []
