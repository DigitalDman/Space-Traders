extends Node

## A global script to manage any global information needed between scenes
var ship_load_info = []
var planet_load_info = []

var in_game_transition = false

var cop_or_pirate = "cop"

var ended_encounter = false
var player_path = []
