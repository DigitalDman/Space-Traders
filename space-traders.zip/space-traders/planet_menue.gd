extends Node2D
var price_of_fuel_per_tile = 15

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	$Screen/Inner_Ring_Displays/Planet.load_planet( GlobalInfo.planet_load_info )
	#print($Screen/Inner_Ring_Displays/Planet.name)
	$Ship.load_ship( GlobalInfo.ship_load_info )
	$Wipe_Transition/AnimationPlayer.play("Wipe_In")
	$Screen/Inner_Ring_Displays/Planet.position = Vector2(596, 76)
	$Screen/Inner_Ring_Displays/Planet.planet_discovered = false


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	main_menue_display()


func _on_leave_planet_pressed() -> void:
	#print(GlobalInfo.planet_load_info)
	GlobalInfo.ship_load_info = $Ship.save_ship()
	
	$Wipe_Transition/AnimationPlayer.play("Wipe_Out")
	await $Wipe_Transition/AnimationPlayer.animation_finished
	
	get_tree().change_scene_to_file("res://Scenes & Scripts/galaxy.tscn")


func main_menue_display():
	var ship_tiles_traveled = ($Ship.max_fuel * 0.25) - ($Ship.fuel_capacity * 0.25)
	#print(ship_tiles_traveled)
	
	### Set the planet name display
	$Screen/Inner_Ring_Displays/Main_Text/Planet_Name.text = $Screen/Inner_Ring_Displays/Planet.planet_name
	
	### Set the balance display ###
	$Screen/Inner_Ring_Displays/Main_Text/Balance.text = "Ship Balance:
		%.2f L" % $Ship.latinum_balance
	
	### Set the refuel cost display ###
	$"Screen/Inner_Ring_Displays/Main_Text/Fuel&Cargo/Ship_Inventory/Refuel_Cost".text = "Refuel Cost:
		%.2f L" % (price_of_fuel_per_tile * ship_tiles_traveled)
	
	### Set the fuel & Cargo displays ###
	$"Screen/Inner_Ring_Displays/Main_Text/Fuel&Cargo/Ship_Inventory/Fuel".text = "%.2f / %.2f" % [$Ship.fuel_capacity, $Ship.max_fuel]
	
	$"Screen/Inner_Ring_Displays/Main_Text/Fuel&Cargo/Ship_Inventory/Max_Cargo".text = "Cargo Bays: %d" %  $Ship.cargo_holds.size()
	$"Screen/Inner_Ring_Displays/Main_Text/Fuel&Cargo/Ship_Inventory/Free_Cargo".text = "Free Cargo Bays:\n %d " % $Ship.get_free_cargo_holds()
	
	###### Disableing buttons depending on different conditions
	if (ship_tiles_traveled > 0 and $Ship.latinum_balance >= (price_of_fuel_per_tile * ship_tiles_traveled)):
		$"Screen/Inner_Ring_Displays/Main_Text/Fuel&Cargo/Refuel".disabled = false
	else:
		$"Screen/Inner_Ring_Displays/Main_Text/Fuel&Cargo/Refuel".disabled = true
