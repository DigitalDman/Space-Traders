extends Node2D
var price_of_fuel_per_tile = 15
var price_per_shield = 25

var buy = false

var total_cart_ammount = 0
var ore_cart = 0
var food_cart = 0
var illegal_cart = 0
var ammount_bought = 1

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	$Screen/Inner_Ring_Displays/Planet.load_planet( GlobalInfo.planet_load_info )
	#print($Screen/Inner_Ring_Displays/Planet.name)
	$Ship.load_ship( GlobalInfo.ship_load_info )
	$Wipe_Transition/AnimationPlayer.play("Wipe_In")
	$Screen/Inner_Ring_Displays/Planet.position = Vector2(596, 76)
	$Screen/Inner_Ring_Displays/Planet.planet_discovered = false
	
	
	#print( $Screen/Inner_Ring_Displays/Planet.illegal_buy_price )
	#print( $Screen/Inner_Ring_Displays/Planet.buy_illegal )


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	main_menue_display()
	buy_sell_menue()


func _on_leave_planet_pressed() -> void:
	#print(GlobalInfo.planet_load_info)
	GlobalInfo.ship_load_info = $Ship.save_ship()
	GlobalInfo.in_game_transition = true
	
	$Wipe_Transition/AnimationPlayer.play("Wipe_Out")
	await $Wipe_Transition/AnimationPlayer.animation_finished
	
	get_tree().change_scene_to_file("res://Scenes & Scripts/galaxy.tscn")


func main_menue_display():
	var ship_tiles_traveled = ($Ship.max_fuel * 0.25) - ($Ship.fuel_capacity * 0.25)
	var ship_balance = $Ship.latinum_balance
	
	### Set the planet name display
	$Screen/Inner_Ring_Displays/Main_Text/Planet_Name.text = $Screen/Inner_Ring_Displays/Planet.planet_name
	
	### Set the balance display ###
	$Screen/Inner_Ring_Displays/Main_Text/Balance.text = "Ship Balance:
		%.2f L" % ship_balance
	
	### Set the refuel cost display ###
	$"Screen/Inner_Ring_Displays/Main_Text/Fuel&Cargo/Ship_Inventory/Refuel_Cost".text = "Refuel Cost:
		%.2f L" % (price_of_fuel_per_tile * ship_tiles_traveled)
	
	### Set the fuel & Cargo displays ###
	$"Screen/Inner_Ring_Displays/Main_Text/Fuel&Cargo/Ship_Inventory/Fuel".text = "%.2f / %.2f" % [$Ship.fuel_capacity, $Ship.max_fuel]
	
	$"Screen/Inner_Ring_Displays/Main_Text/Fuel&Cargo/Ship_Inventory/Max_Cargo".text = "Cargo Bays: %d" %  $Ship.cargo_holds.size()
	$"Screen/Inner_Ring_Displays/Main_Text/Fuel&Cargo/Ship_Inventory/Free_Cargo".text = "Free Cargo Bays:\n %d " % $Ship.get_free_cargo_holds()
	
	$"Screen/Inner_Ring_Displays/Main_Text/Fuel&Cargo/Ship_Inventory/Shield_Strength".text = "Shield Strength: %d / %d" % [$Ship.shield_strength, $Ship.max_shield_strength]
	$"Screen/Inner_Ring_Displays/Main_Text/Fuel&Cargo/Ship_Inventory/Repair_Cost".text = "Repair Cost: %.2f" % (price_of_fuel_per_tile * ($Ship.max_shield_strength - $Ship.shield_strength))
	
	###### Disableing buttons depending on different conditions
	if (ship_tiles_traveled > 0 and ship_balance >= (price_of_fuel_per_tile * ship_tiles_traveled)):
		$"Screen/Inner_Ring_Displays/Main_Text/Fuel&Cargo/Refuel".disabled = false
	else:
		$"Screen/Inner_Ring_Displays/Main_Text/Fuel&Cargo/Refuel".disabled = true
	
	if (ship_balance < 500 or $Ship.cargo_holds.size() >= $Ship.max_cargo_holds ):
		$"Screen/Inner_Ring_Displays/Main_Text/Fuel&Cargo/Increase_Cargo".disabled = true
		
		if ($Ship.cargo_holds.size() >= $Ship.max_cargo_holds):
			$"Screen/Inner_Ring_Displays/Main_Text/Fuel&Cargo/Increase_Cargo/Label".text = "At Max Cargo Holds"
	else:
		$"Screen/Inner_Ring_Displays/Main_Text/Fuel&Cargo/Increase_Cargo".disabled = false
	
	if ($Ship.shield_strength == $Ship.max_shield_strength):
		$"Screen/Inner_Ring_Displays/Main_Text/Fuel&Cargo/Repair".disabled = true
	elif (( $Ship.max_shield_strength - $Ship.shield_strength) * price_per_shield > ship_balance):
		$"Screen/Inner_Ring_Displays/Main_Text/Fuel&Cargo/Repair".disabled = true
	else:
		$"Screen/Inner_Ring_Displays/Main_Text/Fuel&Cargo/Repair".disabled = false

func _on_refuel_pressed() -> void:
	### Refuel & deduct cost. Error Handleing done above
	var ship_tiles_traveled = ($Ship.max_fuel * 0.25) - ($Ship.fuel_capacity * 0.25)
	$Ship.latinum_balance -= price_of_fuel_per_tile * ship_tiles_traveled
	$Ship.fuel_capacity = $Ship.max_fuel


func _on_increase_cargo_pressed() -> void:
	### Deduct cost & add cargo holds ###
	$Ship.latinum_balance -= 500
	
	for i in range(10):
		$Ship.cargo_holds.append(false)


func buy_sell_menue():
	var total = 0.0
	
	$Screen/Inner_Ring_Displays/Buy_Menue/Ship_Inventory/Cargo_Capacity.text = "Cargo Capacity: %d/%d " % [ $Ship.get_free_cargo_holds() ,$Ship.cargo_holds.size()]
	$Screen/Inner_Ring_Displays/Buy_Menue/Ship_Inventory/Ore.text = "Ore: " + str($Ship.ore_held)
	$Screen/Inner_Ring_Displays/Buy_Menue/Ship_Inventory/Food.text = "Food: " + str($Ship.food_held)
	$Screen/Inner_Ring_Displays/Buy_Menue/Ship_Inventory/Illegal_Items.text = "Illegals: " + str($Ship.illegal_held)
	
	$Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Ore/Ore_Cart.text = str(ore_cart)
	$Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Food/Food_Cart.text = str(food_cart)
	$Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Illegals/Illegal_cart.text = str(illegal_cart)
	
	$Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Balance.text = "Balance
	" + str($Ship.latinum_balance)
	
	
	####### Disableing Buttons #########
	#### -1 buttons
	if ore_cart - 1 < 0:
		$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Ore/-1_Ore".disabled = true
	else:
		$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Ore/-1_Ore".disabled = false
	
	if food_cart - 1 < 0:
		$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Food/-1_Food".disabled = true
	else:
		$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Food/-1_Food".disabled = false
	
	if illegal_cart -1 < 0:
		$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Illegals/-1_Illegals".disabled = true
	else:
		$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Illegals/-1_Illegals".disabled = false
	
	###### -5 buttons
	if ore_cart - 5 < 0:
		$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Ore/-5_Ore".disabled = true
	else:
		$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Ore/-5_Ore".disabled = false
	
	if food_cart - 5 < 0:
		$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Food/-5_Food".disabled = true
	else:
		$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Food/-5_Food".disabled = false
	
	if illegal_cart - 5 < 0:
		$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Illegals/-5_Illegals".disabled = true
	else:
		$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Illegals/-5_Illegals".disabled = false
	
	
	
	if buy:
		if $Screen/Inner_Ring_Displays/Planet.has_moon:
			$Screen/Inner_Ring_Displays/Buy_Menue/Moon.visible = true
			
			if $Ship.latinum_balance < 1000000:
				$Screen/Inner_Ring_Displays/Buy_Menue/Moon/Buy_Moon.disabled = true
			else:
				$Screen/Inner_Ring_Displays/Buy_Menue/Moon/Buy_Moon.disabled = false
			
		else:
			$Screen/Inner_Ring_Displays/Buy_Menue/Moon.visible = false
		
		$Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Buy_Button.show()
		$Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Sell_Button.hide()
		
		
		$Screen/Inner_Ring_Displays/Buy_Menue/Ship_Inventory/Price_Headder.text = "Buy Price\nPer 1"
		
		$Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Ore/Ore_Cost.text = "%.2f L" % $Screen/Inner_Ring_Displays/Planet.ore_buy_price
		$Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Food/Food_Cost.text = "%.2f L" % $Screen/Inner_Ring_Displays/Planet.food_buy_price
		$Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Illegals/Illegal_Cost.text = "%.2f L" % $Screen/Inner_Ring_Displays/Planet.illegal_buy_price
		
		
		total = ore_cart * $Screen/Inner_Ring_Displays/Planet.ore_buy_price
		total += food_cart * $Screen/Inner_Ring_Displays/Planet.food_buy_price
		total += illegal_cart * $Screen/Inner_Ring_Displays/Planet.illegal_buy_price
		
		$Screen/Inner_Ring_Displays/Buy_Menue/Ship_Inventory/Total_Cost.text = "Total: %.2f" % total
		
		if $Screen/Inner_Ring_Displays/Planet.buy_food:
			$Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Food.show()
		else:
			$Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Food.hide()
		
		if $Screen/Inner_Ring_Displays/Planet.buy_illegal:
			$Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Illegals.show()
		else:
			$Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Illegals.hide()
		
		if $Screen/Inner_Ring_Displays/Planet.buy_ore:
			$Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Ore.show()
		else:
			$Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Ore.hide()
	
		if (ore_cart + food_cart + illegal_cart + 1) > $Ship.get_free_cargo_holds():
			$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Ore/+1_Ore".disabled = true
			$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Food/+1_Food".disabled = true
			$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Illegals/+1_Illegals".disabled = true
		else:
			$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Ore/+1_Ore".disabled = false
			$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Food/+1_Food".disabled = false
			$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Illegals/+1_Illegals".disabled = false
			
			if (total + $Screen/Inner_Ring_Displays/Planet.ore_buy_price) > $Ship.latinum_balance:
				$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Ore/+1_Ore".disabled = true
			else:
				$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Ore/+1_Ore".disabled = false
			
			if (total + $Screen/Inner_Ring_Displays/Planet.food_buy_price) > $Ship.latinum_balance:
				$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Food/+1_Food".disabled = true
			else:
				$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Food/+1_Food".disabled = false
			
			if (total + $Screen/Inner_Ring_Displays/Planet.illegal_buy_price) > $Ship.latinum_balance:
				$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Illegals/+1_Illegals".disabled = true
			else:
				$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Illegals/+1_Illegals".disabled = false
		
		
		if (ore_cart + food_cart + illegal_cart + 5) > $Ship.get_free_cargo_holds():
			$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Ore/+5_Ore".disabled = true
			$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Food/+5_Food".disabled = true
			$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Illegals/+5_Illegals".disabled = true
		else:
			$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Ore/+5_Ore".disabled = false
			$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Food/+5_Food".disabled = false
			$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Illegals/+5_Illegals".disabled = false
			
			if (total + ($Screen/Inner_Ring_Displays/Planet.ore_buy_price * 5)) > $Ship.latinum_balance:
				$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Illegals/+5_Illegals".disabled = true
			else:
				$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Illegals/+5_Illegals".disabled = false
			
			if (total + ($Screen/Inner_Ring_Displays/Planet.food_buy_price * 5)) > $Ship.latinum_balance:
				$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Food/+5_Food".disabled = true
			else:
				$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Food/+5_Food".disabled = false
			
			if (total + ($Screen/Inner_Ring_Displays/Planet.ore_buy_price * 5)) > $Ship.latinum_balance:
				$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Ore/+5_Ore".disabled = true
			else:
				$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Ore/+5_Ore".disabled = false
		
		
		#### Disableing buttons if it goes over your total balance ####

	else:
		$Screen/Inner_Ring_Displays/Buy_Menue/Moon.visible = false
		
		$Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Sell_Button.show()
		$Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Buy_Button.hide()
		
		$Screen/Inner_Ring_Displays/Buy_Menue/Ship_Inventory/Price_Headder.text = "Sell Price\nPer 1"
		
		$Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Ore/Ore_Cost.text = "%.2f L" % $Screen/Inner_Ring_Displays/Planet.ore_sell_price
		$Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Food/Food_Cost.text = "%.2f L" % $Screen/Inner_Ring_Displays/Planet.food_sell_price
		$Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Illegals/Illegal_Cost.text = "%.2f L" % $Screen/Inner_Ring_Displays/Planet.illegal_sell_price
		
		
		total = ore_cart * $Screen/Inner_Ring_Displays/Planet.ore_sell_price
		total += food_cart * $Screen/Inner_Ring_Displays/Planet.food_sell_price
		total += illegal_cart * $Screen/Inner_Ring_Displays/Planet.illegal_sell_price
		
		$Screen/Inner_Ring_Displays/Buy_Menue/Ship_Inventory/Total_Cost.text = "Total: %.2f" % total
		
		if $Screen/Inner_Ring_Displays/Planet.sell_food:
			$Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Food.show()
		else:
			$Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Food.hide()
		
		if $Screen/Inner_Ring_Displays/Planet.sell_illegal:
			$Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Illegals.show()
		else:
			$Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Illegals.hide()
		
		if $Screen/Inner_Ring_Displays/Planet.sell_ore:
			$Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Ore.show()
		else:
			$Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Ore.hide()
		
		##### Disableing the +1 buttons #####
		if ore_cart +1 > $Ship.ore_held:
			$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Ore/+1_Ore".disabled = true
		else:
			$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Ore/+1_Ore".disabled = false
		
		if food_cart +1 > $Ship.food_held:
			$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Food/+1_Food".disabled = true
		else:
			$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Food/+1_Food".disabled = false
		
		if illegal_cart +1 > $Ship.illegal_held:
			$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Illegals/+1_Illegals".disabled = true
		else:
			$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Illegals/+1_Illegals".disabled = false
		
		
		if ore_cart +5 > $Ship.ore_held:
			$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Ore/+5_Ore".disabled = true
		else:
			$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Ore/+5_Ore".disabled = false
		
		if food_cart +5 > $Ship.food_held:
			$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Food/+5_Food".disabled = true
		else:
			$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Food/+5_Food".disabled = false
		
		if illegal_cart +5 > $Ship.illegal_held:
			$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Illegals/+5_Illegals".disabled = true
		else:
			$"Screen/Inner_Ring_Displays/Buy_Menue/Buy_Buttons/Illegals/+5_Illegals".disabled = false


func buy_food():
	await get_tree().create_timer(0.1).timeout
	food_cart += ammount_bought * 1

func buy_ore():
	await get_tree().create_timer(0.1).timeout
	ore_cart += ammount_bought * 1

func buy_illegals():
	await get_tree().create_timer(0.1).timeout
	illegal_cart += ammount_bought * 1

func increase_1():
	ammount_bought = 1

func decrease_1():
	ammount_bought = -1

func increase_5():
	ammount_bought = 5

func decrease_5():
	ammount_bought = -5


func _on_buy_pressed() -> void:
	buy = true
	$Screen/AnimationPlayer.play("Main to Buy-Sell")


func _on_sell_pressed() -> void:
	buy = false
	$Screen/AnimationPlayer.play("Main to Buy-Sell")

func _on_return_button_pressed() -> void:
	$Screen/AnimationPlayer.play_backwards("Main to Buy-Sell")

func _on_buy_button_pressed() -> void:
	var total = 0
	
	total = ore_cart * $Screen/Inner_Ring_Displays/Planet.ore_sell_price
	total += food_cart * $Screen/Inner_Ring_Displays/Planet.food_sell_price
	total += illegal_cart * $Screen/Inner_Ring_Displays/Planet.illegal_sell_price
	
	$Ship.latinum_balance -= total
	$Ship.ore_held += ore_cart
	$Ship.food_held += food_cart
	$Ship.illegal_held += illegal_cart
	
	total_cart_ammount = ore_cart + food_cart + illegal_cart
	
	ore_cart = 0
	food_cart = 0
	illegal_cart = 0
	
	var total_added = 0
	
	#print("Total Cart: ", total_cart_ammount)
	for i in range($Ship.cargo_holds.size()):
		if $Ship.cargo_holds[i] == false:
			$Ship.cargo_holds[i] = true
			total_added += 1
			#print(total_added)
		
		if (total_added == total_cart_ammount):
			break


func _on_sell_button_pressed() -> void:
	var total = 0
	
	total = ore_cart * $Screen/Inner_Ring_Displays/Planet.ore_sell_price
	total += food_cart * $Screen/Inner_Ring_Displays/Planet.food_sell_price
	total += illegal_cart * $Screen/Inner_Ring_Displays/Planet.illegal_sell_price
	
	$Ship.latinum_balance += total
	$Ship.ore_held -= ore_cart
	$Ship.food_held -= food_cart
	$Ship.illegal_held -= illegal_cart
	
	total_cart_ammount = ore_cart + food_cart + illegal_cart
	
	ore_cart = 0
	food_cart = 0
	illegal_cart = 0
	
	var total_added = 0
	for i in range($Ship.cargo_holds.size()):
		if $Ship.cargo_holds[i] == true:
			$Ship.cargo_holds[i] = false
			total_added += 1
		
		if (total_added == total_cart_ammount):
			break


func _on_repair_pressed() -> void:
	### Refuel & deduct cost. Error Handleing done above
	var ship_damage_taken = $Ship.max_shield_strength - $Ship.shield_strength
	$Ship.latinum_balance -= price_per_shield * ship_damage_taken
	$Ship.shield_strength = $Ship.max_shield_strength
