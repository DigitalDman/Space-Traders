extends Node2D

static var planet_sprites = ["Green_Ring", "Lava", "Petropia", "Water_Core", "Yellow_1", "Pangea", "Death_Star"]
var sprite_used = -1

## VARIABLES ###
var planet_name = "" # Save out planet name
var location = Vector2i(-1,-1)
static var planet_locations = [] ## So we dont have 2 planets in the same location
static var names_used = []## So we dont accidentally repeat names
## Variables to see if this planet even buys or sells ore/food
var sell_ore = -1
var sell_food = -1
var sell_illegal = 0

var buy_ore = -1
var buy_food = -1
var buy_illegal = 0

#### Price variables for if food/ore can be bought/sol
var ore_buy_price = 0
var food_buy_price = 0
var illegal_buy_price = 0

var ore_sell_price = 0
var food_sell_price = 0
var illegal_sell_price = 0

var planet_discovered = false
var has_moon = false
## @export gives it a slot on my inspector window (did it as an export so I can change it when testing easier)
@export var planet_buy_sell_min = 25
@export var planet_buy_sell_max = 100

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if planet_discovered:
		$Name_Tag.text = planet_name
		$Name_Tag.show()


func new_planet(): ## A function to create a new planet
	var generator = RandomNumberGenerator.new() ## Create a new Random object
	var illegal_chance = generator.randi_range(0,50) ## Generates the chance that the planet buys or sells illegal goods
	## Would make a weighted generator but I am not doing that again after the Intruder Game
	## randi_range is inclusive
	
	var name_list = [] ## Create a blank arrayList to store the possible planet names
	var file = FileAccess.open("res://Planet_Names.txt", FileAccess.READ) ## Make a read-only file object
	## Looks at our Planet_Names file
	var name_index = 0
	var location_x = 0
	var location_y = 0
	
	var planet_sprite_index = generator.randi_range(0, planet_sprites.size() - 1) ## Generate a random planet sprite from this
	$Planet_Sprite.play( planet_sprites[planet_sprite_index] ) ## And set the planet to whatever it rolls
	sprite_used = planet_sprite_index
	## Uses an Animated Sprite so I can quick switch between sprites easily if their all different animation tracks
	
	### While the File isnt empty, save every line to the array
	while file.get_position() < file.get_length():
		name_list.append(file.get_line())
	
	##print(name_list) ## Prints for testing
	#for name_given in name_list:
		#print(name_given)
	
	#### Generate the name ####
	while (!names_used.has(planet_name)):
		name_index = generator.randi_range(0, name_list.size() - 1) ## Generates an index between 0 & the size of the Array
		planet_name = name_list[name_index] ## And here we have our generated planet name
		$Name_Tag.text = planet_name ## Set the nametags text to the planets name
		#print(planet_name) ## print for testing
		
		if (!names_used.has(planet_name)): # Only add it to the list when its name isnt there
			names_used.append(planet_name)
	
	#print(names_used)
	### Lets generate the tile location ###
	
	while (true):
		#print(planet_name)
		## Generate the x & y positions
		location_x = generator.randi_range(0,99)
		location_y = generator.randi_range(0,99)
		
		location = Vector2i(location_x, location_y)
		#print(global_position)
		## Multiplied by 16 since thats going to be in the center of the tile, and each tile is 32/32
		
		if (!planet_locations.has(location)):
			
			planet_locations.append(location) ## Save to our static list so we dont have 2 planets in 1 location
			
			## We also have to block off all neighboring locations (Just so the planets arnt right next to eachother)
			planet_locations.append( Vector2i(location_x + 1, location_y) )
			planet_locations.append( Vector2i(location_x +1, location_y +1) )
			planet_locations.append( Vector2i(location_x +1, location_y -1) )
			planet_locations.append( Vector2i(location_x, location_y + 1) )
			planet_locations.append( Vector2i(location_x, location_y - 1) )
			planet_locations.append( Vector2i(location_x -1, location_y +1) )
			planet_locations.append( Vector2i(location_x -1, location_y) )
			planet_locations.append( Vector2i(location_x -1, location_y -1) )
			break;
			#print(planet_locations)
			#print("==================================================================================================")
		#else:
		#	print("reroll for: ", planet_name)
		#	$Name_Tag.show()
	
	global_position = Vector2(location_x * 32, location_y * 32) ## Actually put the planets position there
	
	## Up next, seeing what the planets selling
	sell_food = generator.randi_range(0,1) ## Generate between 0 & 1 (true or false)
	sell_ore = generator.randi_range(0,1) ## Same as above
	
	
	## Lets find those prices
	if (sell_food == 1):
		food_sell_price = generator.randi_range(planet_buy_sell_min, planet_buy_sell_max)
		## Generate between the provided max & min
		
	if (sell_ore == 1):
		ore_sell_price = generator.randi_range(planet_buy_sell_min, planet_buy_sell_max)
		## Generate between the provided max & min
	
	## Now for what they're buying
	buy_food = generator.randi_range(0,1) ## Generate between 0 & 1 (true or false)
	buy_ore = generator.randi_range(0,1) ## Same as above
	
	## Lets find those prices
	if (buy_food == 1):
		food_buy_price = generator.randi_range(planet_buy_sell_min, planet_buy_sell_max)
		## Generate between the provided max & min
		
	if (buy_ore == 1):
		ore_buy_price = generator.randi_range(planet_buy_sell_min, planet_buy_sell_max)
		## Generate between the provided max & min
		
	### Now for the fun part, CRIME ###
	var sell_illegal_roll = randi_range(1,100) ## Lets roll to see if we're commiting crimes or not on this planet
	var buy_illegal_roll = randi_range(1,100) ## Lets roll to see if we're commiting crimes or not on this planet
	
	if (sell_illegal_roll <= illegal_chance): ## Only commit crimes if you rolled under or at the illegal chance
		illegal_sell_price = randi_range(planet_buy_sell_min, planet_buy_sell_max)
		
		sell_illegal = 1
	
	if (buy_illegal_roll <= illegal_chance): ## Only commit more crimes if your rolled under or at the illegal chance
		illegal_buy_price = randi_range(planet_buy_sell_min, planet_buy_sell_max)
		buy_illegal = 1
		#print(planet_name + " : " + str(illegal_buy_price) + " : " + str(buy_illegal))

func load_planet(data : Array):
	#print("____________________________________________________________________")
	#print(data)
	planet_name = data[0]
	location = data[1]
	sell_ore = data[2]
	sell_food = data[3]
	sell_illegal = data[4]
	buy_ore = data[5]
	buy_food = data[6]
	buy_illegal = data[7]
	ore_buy_price = data[8]
	food_buy_price = data[9]
	ore_sell_price = data[10]
	illegal_buy_price = data[11]
	food_sell_price = data[12]
	illegal_sell_price = data[13]
	sprite_used = data[14]
	planet_discovered = data[15]
	has_moon = data[16]
	#print(sprite_used)
	#print(data)
	
	$Planet_Sprite.play( planet_sprites[sprite_used] ) ## And set the planet to whatever it rolls
	global_position = Vector2(location.x * 32, location.y * 32) ## Actually put the planets position there

func save_planet() -> Array: ## A function to save our planet
	var save_data = [] ## Create an array for our save data
	save_data.append(planet_name)
	save_data.append(location)
	save_data.append(sell_ore)
	save_data.append(sell_food)
	save_data.append(sell_illegal)
	save_data.append(buy_ore)
	save_data.append(buy_food)
	save_data.append(buy_illegal)
	save_data.append(ore_buy_price)
	save_data.append(food_buy_price)
	save_data.append(illegal_buy_price)
	save_data.append(ore_sell_price)
	save_data.append(food_sell_price)
	save_data.append(illegal_sell_price)
	save_data.append(sprite_used)
	save_data.append(planet_discovered)
	save_data.append(has_moon)
	
	return save_data ## Return our save_data Array
