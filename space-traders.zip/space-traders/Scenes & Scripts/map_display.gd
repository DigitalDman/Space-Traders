extends Sprite2D

## Save our X & Y quadrants as variables
var x_quadrant = ""
var y_quadrant = 0
signal map_button_pressed(x : String, y : int )

### Detect when anything in Group_A is pressed
func group_A_pressed():
	#print("A")
	x_quadrant = "A"
	await  get_tree().create_timer(0.1).timeout
	map_button_pressed.emit(x_quadrant, y_quadrant)

### Detect when anything in Group_B is pressed
func group_B_pressed():
	#print("B")
	x_quadrant = "B"
	await  get_tree().create_timer(0.1).timeout
	map_button_pressed.emit(x_quadrant, y_quadrant)

### Detect when anything in Group_C is pressed
func group_C_pressed():
	#print("C")
	x_quadrant = "C"
	await  get_tree().create_timer(0.1).timeout
	map_button_pressed.emit(x_quadrant, y_quadrant)

### Detect when anything in Group_D is pressed
func group_D_pressed():
	#print("D")
	x_quadrant = "D"
	await  get_tree().create_timer(0.1).timeout
	map_button_pressed.emit(x_quadrant, y_quadrant)


### Detect when anything in Group_1 is pressed
func group_1_pressed():
	#print("1")
	y_quadrant = 1


### Detect when anything in Group_2 is pressed
func group_2_pressed():
	#print("2")
	y_quadrant = 2


### Detect when anything in Group_3 is pressed
func group_3_pressed():
	#print("3")
	y_quadrant = 3


### Detect when anything in Group_4 is pressed
func group_4_pressed():
	#print("4")
	y_quadrant = 4

### Detect when anything in Group_5 is pressed
func group_5_pressed():
	#print("5")
	y_quadrant = 5
