extends Control
## A script for all test displays needed when running
## All nodes here will be hidden in final version

## Create a grid variable so we can view our AStar
var grid : AStarGrid2D :
	set(v): grid = v; queue_redraw() ## tells our code to redraw the grid when updated
	
var show_grid = false ## So we know if we want our grid to be displayed or not


func _on_check_box_toggled(toggled_on: bool) -> void:
	show_grid = toggled_on ## set show_grid to whatever the toggle box does

func _draw() -> void: ## Godots built in draw function, to draw simple 2D shapes
	if !grid or !show_grid:
		return ## Exit from draw if we're not displaying our ASTar
	
	## Now lets loop through all our tiles
	for x in grid.region.size.x:
		for y in grid.region.size.y:
			var tile = Vector2(x,y)
			draw_rect(Rect2(tile * grid.cell_size, grid.cell_size), Color(0,1,0,0.3))
			## Draws each tile as a slightly transparant green colour
