extends Node2D
var camera_positions = [Vector2(0,0), Vector2(800, 0), Vector2(1600,0), Vector2(2400,0),
						Vector2(0,640), Vector2(800, 640), Vector2(1600,640), Vector2(2400,640),
						Vector2(0,1280), Vector2(800, 1280), Vector2(1600,1280), Vector2(2400,1280),
						Vector2(0,1920), Vector2(800, 1920), Vector2(1600,1920), Vector2(2400,1920),
						Vector2(0,2560), Vector2(800, 2560), Vector2(1600,2560), Vector2(2400,2560)]

var x_quadrant = 1
var y_quadrant = 1
var quadrant_name = "Q1A"


var old_camera_position = Vector2.ZERO
var old_quadrant_name = ""
var old_x_quadrant = 0
var old_y_quadrant = 0
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	$Camera/UI/Quadrant_Lable_Fill.text = quadrant_name ## Update the Quadrant name display
	
	### Set our X displays ###
	$Camera/UI/X_Displays/X_Min.text = str( 25 * (x_quadrant - 1))
	$Camera/UI/X_Displays/X_Mid1.text = str( "%.0f" % (25 * (x_quadrant - 0.8) -1) ) ## 25 * 0.2 is 5
	$Camera/UI/X_Displays/X_Mid2.text = str( "%.0f" % (25 * (x_quadrant - 0.6) -1) ) ## 25 * 0.2 is 10
	$Camera/UI/X_Displays/X_Mid3.text = str( "%.0f" % (25 * (x_quadrant - 0.4) -1) ) ## 25 * 0.2 is 15
	$Camera/UI/X_Displays/X_Mid4.text = str( "%.0f" % (25 * (x_quadrant - 0.2) -1) ) ## 25 * 0.2 is 20
	$Camera/UI/X_Displays/X_Max.text = str( 25 * x_quadrant - 1)  ## 25 * 1 is 25
	
	### Set our Y display
	$Camera/UI/Y_Displays/Y_Min.text = str(20 * (y_quadrant - 1))
	$Camera/UI/Y_Displays/Y_Mid1.text = str( "%.0f" % (20 * (y_quadrant - 0.75) -1)) ## 20 * 0.25 is 5
	$Camera/UI/Y_Displays/Y_Mid2.text = str( "%.0f" % (20 * (y_quadrant - 0.5) -1)) ## 200 * 0.5 is 10
	$Camera/UI/Y_Displays/Y_Mid3.text = str( "%.0f" % (20 * (y_quadrant - 0.25) -1)) ## 20 * 0.75 is 15
	$Camera/UI/Y_Displays/Y_Max.text = str(20 * y_quadrant - 1)  ## 20 * 1 is 20
	

#### SWITCH TO VIEW THE QUADRANTS & UPDATE THE QUADRANT VARIABLES FOR DISPLAY ####
func _on_q_1_body_entered(body: Node2D) -> void:
	$Camera.position = camera_positions[0]
	x_quadrant = 1
	y_quadrant = 1
	quadrant_name = "Q1A"

func _on_q_2_body_entered(body: Node2D) -> void:
	$Camera.position = camera_positions[1]
	x_quadrant = 2
	y_quadrant = 1
	quadrant_name = "Q1B"
	
func _on_q_3_body_entered(body: Node2D) -> void:
	$Camera.position = camera_positions[2]
	x_quadrant = 3
	y_quadrant = 1
	quadrant_name = "Q1C"

func _on_q_4_body_entered(body: Node2D) -> void:
	$Camera.position = camera_positions[3]
	x_quadrant = 4
	y_quadrant = 1
	quadrant_name = "Q1D"

func _on_q_5_body_entered(body: Node2D) -> void:
	$Camera.position = camera_positions[4]
	x_quadrant = 1
	y_quadrant = 2
	quadrant_name = "Q2A"

func _on_q_6_body_entered(body: Node2D) -> void:
	$Camera.position = camera_positions[5]
	x_quadrant = 2
	y_quadrant = 2
	quadrant_name = "Q2B"
	
func _on_q_7_body_entered(body: Node2D) -> void:
	$Camera.position = camera_positions[6]
	x_quadrant = 3
	y_quadrant = 2
	quadrant_name = "Q2C"

func _on_q_8_body_entered(body: Node2D) -> void:
	$Camera.position = camera_positions[7]
	x_quadrant = 4
	y_quadrant = 2
	quadrant_name = "Q2D"

func _on_q_9_body_entered(body: Node2D) -> void:
	$Camera.position = camera_positions[8]
	x_quadrant = 1
	y_quadrant = 3
	quadrant_name = "Q3A"

func _on_q_10_body_entered(body: Node2D) -> void:
	$Camera.position = camera_positions[9]
	x_quadrant = 2
	y_quadrant = 3
	quadrant_name = "Q3B"

func _on_q_11_body_entered(body: Node2D) -> void:
	$Camera.position = camera_positions[10]
	x_quadrant = 3
	y_quadrant = 3
	quadrant_name = "Q3C"

func _on_q_12_body_entered(body: Node2D) -> void:
	$Camera.position = camera_positions[11]
	x_quadrant = 4
	y_quadrant = 3
	quadrant_name = "Q3D"

func _on_q_13_body_entered(body: Node2D) -> void:
	$Camera.position = camera_positions[12]
	x_quadrant = 1
	y_quadrant = 4
	quadrant_name = "Q4A"

func _on_q_14_body_entered(body: Node2D) -> void:
	$Camera.position = camera_positions[13]
	x_quadrant = 2
	y_quadrant = 4
	quadrant_name = "Q4B"

func _on_q_15_body_entered(body: Node2D) -> void:
	$Camera.position = camera_positions[14]
	x_quadrant = 3
	y_quadrant = 4
	quadrant_name = "Q4C"

func _on_q_16_body_entered(body: Node2D) -> void:
	$Camera.position = camera_positions[15]
	x_quadrant = 4
	y_quadrant = 4
	quadrant_name = "Q4D"

func _on_q_17_body_entered(body: Node2D) -> void:
	$Camera.position = camera_positions[16]
	x_quadrant = 1
	y_quadrant = 5
	quadrant_name = "Q5A"

func _on_q_18_body_entered(body: Node2D) -> void:
	$Camera.position = camera_positions[17]
	x_quadrant = 2
	y_quadrant = 5
	quadrant_name = "Q5B"

func _on_q_19_body_entered(body: Node2D) -> void:
	$Camera.position = camera_positions[18]
	x_quadrant = 3
	y_quadrant = 5
	quadrant_name = "Q5C"

func _on_q_20_body_entered(body: Node2D) -> void:
	$Camera.position = camera_positions[19]
	x_quadrant = 4
	y_quadrant = 5
	quadrant_name = "Q5D"


func _on_map_display_map_button_pressed(x: String, y: int) -> void:
	var final_quadrant = -1
	old_camera_position = $Camera.position
	old_quadrant_name = quadrant_name
	old_x_quadrant = x_quadrant
	old_y_quadrant = y_quadrant
	
	quadrant_name = "Q" + str(y) + x ## Save the quadrant name
	
	y_quadrant = y
	
	### Figure out what X quadrant we're in
	match x:
		"A":
			x_quadrant = 1
			#print(final_quadrant)
		"B":
			x_quadrant = 2
		"C":
			x_quadrant = 3
		"D":
			x_quadrant = 4
	
	#print("X: ", x_quadrant)
	#print("Y: ", y_quadrant)
	#
	final_quadrant = 4 * (y - 1)
	#print(final_quadrant)
	final_quadrant += (x_quadrant - 1)
	#print(final_quadrant)
	$Camera.position = camera_positions[final_quadrant]
	$Camera/UI/Display_Ring.hide()
	$Camera/UI/Map_Display.hide()
	$Camera/UI/Grid_Buttons.hide()
	$Camera/UI/CLose_Map.show()


func _on_c_lose_map_pressed() -> void:
	$Camera.position = old_camera_position
	quadrant_name = old_quadrant_name
	x_quadrant = old_x_quadrant
	y_quadrant = old_y_quadrant
	
	
	$Camera/UI/Display_Ring.show()
	$Camera/UI/Map_Display.show()
	$Camera/UI/Grid_Buttons.show()
	$Camera/UI/CLose_Map.hide()
