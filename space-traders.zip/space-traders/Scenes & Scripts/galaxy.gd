extends Node
var planet_save_path = "user://planets.save" # Just save the Path for our file as a string
var remaining_save_data = "user://other.save" ## Just saveing the path for the rest of the data needed

@export var min_planets = 12
@export var max_planets = 20
var planets = {} ## Blank dictionary to hold our planets eventually
## This dictionary is going to be sorted as Location : Planet ( Vector2 : Planet )

###### MOVEMENT STUFF (IDK why but I wanted to use an AStar grid and here we are)
@onready var aStar_grid = AStarGrid2D.new()



# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	$Camera_Positions/Camera/Wipe_Transition/AnimationPlayer.play("Wipe_In")
	
	if (GlobalInfo.in_game_transition or GlobalInfo.ended_encounter):
		load_data()
		GlobalInfo.in_game_transition = false
		$Ship.load_ship( GlobalInfo.ship_load_info )
		if GlobalInfo.ended_encounter:
			$Ship.grid_setup(aStar_grid)
			$Ship.path = GlobalInfo.player_path
			$Ship.is_moving = true
	else:
		new_universe()
	#print(planets.keys())
	aStar()
	#load_data()
	
	#await get_tree().create_timer(15).timeout
	#save()


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	$Testing_Displays.grid = aStar_grid
	$Ship.grid_setup(aStar_grid)
	#print("%.2f" % $Ship.fuel_capacity)
	
	### Disable/Enable the menue button depending on if the players moving or not
	if $Ship.is_moving:
		$Camera_Positions/Camera/UI/Open_Menue.disabled = true
	else:
		$Camera_Positions/Camera/UI/Open_Menue.disabled = false
	
	### Show the planets name if its been discovered or not
	if planets.has( $Ship.current_cell ):
		planets[$Ship.current_cell].planet_discovered = true
	
	#### Enable/Disable the planet button if the player stops on a planet ####
	if planets.has( $Ship.current_cell ) and !$Ship.is_moving:
		$Camera_Positions/Camera/UI/Planet_Menue.disabled = false
	else:
		$Camera_Positions/Camera/UI/Planet_Menue.disabled = true
	
	


func save():
	var file = FileAccess.open(planet_save_path, FileAccess.WRITE) ## Make a write-only file object
	var remaining_file = FileAccess.open(remaining_save_data, FileAccess.WRITE) 
	#print("Saved")
	### Loop through out planets & save them all ###
	for key in planets:
		file.store_var( planets[key].save_planet() )
	
	remaining_file.store_var( $Ship.save_ship() )
	remaining_file.store_var( $Camera_Positions.x_quadrant )
	remaining_file.store_var( $Camera_Positions.y_quadrant )
	remaining_file.store_var( $Camera_Positions.quadrant_name )
	remaining_file.store_var( $Camera_Positions/Camera.position )
	

func load_data():
	if FileAccess.file_exists(planet_save_path): ## only load if the file exists
		var file = FileAccess.open(planet_save_path, FileAccess.READ) ## Make a read-only file object
		
		### Loop until we reach the end of the file
		while file.get_position() < file.get_length():
			var new_planet = $Refrence_Planet.duplicate()
			var planet_data = file.get_var()
			add_child(new_planet)
			new_planet.load_planet(planet_data)
			planets[new_planet.location] = new_planet
		#print()
		
		file.close() ## Close our file
	
	## Now load everything else ##
	if FileAccess.file_exists(remaining_save_data): ## only load if the file exists
		var file = FileAccess.open(remaining_save_data, FileAccess.READ) ## Make a read-only file object
		
		$Ship.load_ship(file.get_var()) ## Load the ship
		$Camera_Positions.x_quadrant = file.get_var()
		$Camera_Positions.y_quadrant = file.get_var()
		$Camera_Positions.quadrant_name = file.get_var()
		$Camera_Positions/Camera.position = file.get_var()
		
		#for i in range(5):
		#	print(file.get_var())
			
		#print()
		
		file.close() ## Close our file
	
	#print(planets)


func new_universe():
	var planet_generator = RandomNumberGenerator.new() ## Create a new random to generate how many planets this universe has
	var total_planets = planet_generator.randi_range(min_planets, max_planets)
	
	for i in range(total_planets):
		var new_planet = $Refrence_Planet.duplicate()
		add_child(new_planet) ## Adds this as a child of our galaxy node (main node)
		new_planet.new_planet()
		
		if (i == 0):
			new_planet.has_moon = true
			#print(new_planet.planet_name)
			#print(new_planet.location)
		
		planets[new_planet.location] = new_planet


func aStar():
	### Pretty much just setting it to never move diagonally and to always move off of right angles ###
	#aStar_grid.default_compute_heuristic = AStarGrid2D.HEURISTIC_MANHATTAN
	#aStar_grid.default_estimate_heuristic = AStarGrid2D.HEURISTIC_MANHATTAN
	#aStar_grid.diagonal_mode = AStarGrid2D.DIAGONAL_MODE_NEVER
	
	aStar_grid.size = Vector2i(100,100) ## declare the grid as 100x100 cells
	aStar_grid.cell_size = Vector2(32,32)
	aStar_grid.update()
	
	#print(aStar_grid.get_point_position(Vector2i(0,0)))


func _on_planet_menue_pressed() -> void:
	var planet_data = planets[$Ship.current_cell].save_planet()
	#print(planet_data)
	GlobalInfo.planet_load_info = planet_data
	#print(GlobalInfo.planet_load_info)
	GlobalInfo.ship_load_info = $Ship.save_ship()
	
	save()
	$Camera_Positions/Camera/Wipe_Transition/AnimationPlayer.play("Wipe_Out")
	await $Camera_Positions/Camera/Wipe_Transition/AnimationPlayer.animation_finished
	
	get_tree().change_scene_to_file("res://planet_menue.tscn")


func _on_ship_encounter() -> void:
	save()
