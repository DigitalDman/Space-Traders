extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
	#$Display_Inner/Text/Balance.text = "LATINUM: " + str(ShipInfo.balance)
	## Set the balance display to how much Latinum we own
	#$Display_Inner/Text/Coordinates.text = "Location: " + str(ShipInfo.ship_location)
	
func _on_open_menue_pressed() -> void:
	#$UI/Open_Menue.hide() ## When you press the open button, hide it
	$Display_Inner/Text/Balance.text = "Latinum: " + str($"../../../Ship".latinum_balance)
	$Display_Inner/Text/Coordinates.text = "Location: " + str($"../../../Ship".current_cell)
	$Move_Display/Text/Coordinates.text = "Current Location: " + str($"../../../Ship".current_cell)
	$Display_Inner/Text/Free_Cargo.text = "Free Cargo Holds: " + str($"../../../Ship".get_free_cargo_holds())
	$Display_Inner/Text/Total_Cargo.text = "Total Cargo Holds: " + str($"../../../Ship".cargo_holds.size())
	$Display_Inner/Text/Ore.text = "Ore: " + str($"../../../Ship".ore_held)
	$Display_Inner/Text/Food.text = "Food: " + str($"../../../Ship".food_held)
	$Display_Inner/Text/Illegal.text = "Illegal Items: " +  str($"../../../Ship".illegal_held)
	$Display_Inner/Text/Status_Points.text = "Status Points: " + str($"../../../Ship".status_points)
	$Display_Inner/Text/Fuel.text = "Fuel: %.2f / %.2f" % [$"../../../Ship".fuel_capacity, $"../../../Ship".max_fuel]
	
	$AnimationPlayer.play("Board_Appear") ## And play the open animation

func _on_enter_coordinates_pressed() -> void:
	## Save our X & Y input
	var text_given_x = $Move_Display/Text/Location_Input/X_Input.text
	var text_given_y = $Move_Display/Text/Location_Input/Y_Input.text
	var int_x = 0 # X & Y cords as ints, currently set to 0
	var int_y = 0
	
	## Save it to our location if we can save them to an int
	if (text_given_x.is_valid_int()):
			## Save it to our location if we can save it to an int
		if (text_given_y.is_valid_int()):
			
			### Convert our cordinates into ints ###
			int_x = int(text_given_x)
			int_y = int(text_given_y)
			
			if (int_x >= 0 and int_y >= 0):
				#print("MOVING")
				$"../../../Ship".move( Vector2i(int_x, int_y) ) ## Call the players move function when proper coordinates are input
				## Close the menue when cooridinates are properly input
				_on_close_menue_2_pressed()
				
			else:
				$Error/Error_Code.text = "ONLY POSITIVE INTEGER COORINATES ALLOWED"
				$AnimationPlayer.play("ERROR")

		else: 
			$Error/Error_Code.text = "ONLY INTEGER COORINATES ALLOWED"
			$AnimationPlayer.play("ERROR")
		
	else: 
		$Error/Error_Code.text = "ONLY INTEGER COORINATES ALLOWED"
		$AnimationPlayer.play("ERROR")
	
	

func _on_move_pressed() -> void:
	$AnimationPlayer.play("Move_Display_Appear")


func _on_close_menue_pressed() -> void:
	$AnimationPlayer.play("Board_close") ## And when you close it play the close animation 
	#$UI/Open_Menue.show() ## And show the open button


func _on_return_pressed() -> void:
	$AnimationPlayer.play("Move_To_Regular")


func _on_close_menue_2_pressed() -> void:
	$AnimationPlayer.play("Move_To_Regular")
	await $AnimationPlayer.animation_finished
	$AnimationPlayer.play("Board_close")


func _on_map_pressed() -> void:
	$AnimationPlayer.play("Map_Menue_Appear")


func _on_return_map_pressed() -> void:
	$AnimationPlayer.play_backwards("Map_Menue_Appear")


func _on_close_menue_3_pressed() -> void:
	$AnimationPlayer.play_backwards("Map_Menue_Appear")
	await $AnimationPlayer.animation_finished
	$AnimationPlayer.play("Move_To_Regular")
	await $AnimationPlayer.animation_finished
	$AnimationPlayer.play("Board_close")
